import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  public setItem(key: string, value: string) {
    localStorage.setItem(key, value);
  }
    
  public getItem(){ 
    return localStorage.getItem('todoData')
  }
}
