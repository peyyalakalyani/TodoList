import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { TodoService } from '../todo.service';

interface Todo {
  content: string;
  id?: number;
  datemodified?: any;
  isDone?: boolean;
}

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit {
  
   editIndex: any;
   todoList:any=[];
   todoVal:any="";
   myForm:FormGroup;
   submit:boolean=false;
   date:any='';
  inputValue: Todo = {
    content: "",
  }
  inputId: any=1;
  editValue:boolean=false;
  todoCollection:any=[];
  currentDate:any;
      
  constructor(public fb:FormBuilder,public datepipe: DatePipe, public todoService:TodoService) {     
     this.date=new Date();      
     this.currentDate =this.datepipe.transform(this. date, 'yyyy-MM-dd HH:mm:ss');
  }  

  ngOnInit(): void {
    let retriveTodo = JSON.parse(localStorage.getItem('todoData') || '[]');
    this.getTodoList(retriveTodo);   
  }
  addNewItem(){          
    let retriveTodo = JSON.parse(localStorage.getItem('todoData') || '[]');

    if(retriveTodo.length >0){
      this.inputValue.id = retriveTodo.length+1;    
      this.inputValue.datemodified = this.currentDate;
      this.inputValue.isDone = false;
      retriveTodo.push(this.inputValue);
      localStorage.setItem('todoData',JSON.stringify(retriveTodo));   
      
    }
    else{
     this.inputValue.id = this.inputId++;    
     this.inputValue.datemodified = this.currentDate;
     this.inputValue.isDone = false;
     retriveTodo.push(this.inputValue);
     localStorage.setItem('todoData',JSON.stringify(retriveTodo));   
     
    }
    this.getTodoList(retriveTodo);   
   

  }

  getTodoList(retriveTodo){    
    this.todoList=retriveTodo;
    console.log('getlist',this.todoList); 

  }
  saveNewItem(){
    let retriveTodo = JSON.parse(localStorage.getItem('todoData') || '[]');    
    let objIndex = retriveTodo.findIndex((obj => obj.id == this.editIndex));
    retriveTodo[objIndex].content = this.inputValue.content;
    retriveTodo[objIndex].datemodified = this.currentDate;
    retriveTodo[objIndex].isDone = false;
    localStorage.setItem('todoData',JSON.stringify(retriveTodo));    
    this.getTodoList(retriveTodo);
    this.editValue = false;
    this.inputValue.content = "";
  }
  checkComplete(list){    
    let retriveTodo = JSON.parse(localStorage.getItem('todoData') || '[]');    
    let objIndex = retriveTodo.findIndex((obj => obj.id == list.id));
    retriveTodo[objIndex].content = list.content;
    retriveTodo[objIndex].datemodified = this.currentDate;
    retriveTodo[objIndex].isDone = true;
    localStorage.setItem('todoData',JSON.stringify(retriveTodo));    
    this.getTodoList(retriveTodo);    
    console.log('done',list,this.editIndex,retriveTodo);
 }
  
  editList(list){
    this.inputValue.content = list.content;
    this.editValue = true;
    this.editIndex = list.id;
    console.log('edit',list,this.editIndex);
  }
  
  

}
